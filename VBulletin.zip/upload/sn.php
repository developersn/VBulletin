<?php
try
{
	date_default_timezone_set("Asia/Tehran");
	$time = time();
// Security
@session_start();
$sec = uniqid();
$md = md5($sec.'vm');
// Security

	
$callBackUrl = $_POST['pl_callback_url']."&sec=".$sec."&md=".$md;
$data_string = json_encode(array(
'pin'=> $_POST['pl_mid'],
'price'=> $_POST['pl_amount'],
'callback'=> $callBackUrl ,
'order_id'=> $time,
'ip'=> $_SERVER['REMOTE_ADDR'],
'callback_type'=>2
));




$ch = curl_init('https://developerapi.net/api/v1/request');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);


$json = json_decode($result,true);
if(!empty($json['result']) AND $json['result'] == 1)
{
		@session_start();
// Set Session
$_SESSION[$sec] = [
	'price'=> $_POST['pl_amount'],
	'order_id'=>$time ,
	'au'=>$json['au'] ,
];
		 echo ('<div style="display:none">'.$json['form'].'</div>Please wait ... <script language="javascript">document.payment.submit(); </script>');
	}
	else
	{
		echo "Error:". $json['result'];
	}
}
catch (SoapFault $ex)
{
	echo  'Error: '.$ex->getMessage();
}
exit;
?>